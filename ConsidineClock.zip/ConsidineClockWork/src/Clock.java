import edu.du.dudraw.DUDraw;
import java.time.LocalTime;

public class Clock {

	public static void main(String[] args) {
		//Create canvas
		DUDraw.enableDoubleBuffering();
		DUDraw.setCanvasSize(600,600);
	
		//Set Scale for Canvas
		DUDraw.setScale(-1,1);
		//Clock Face Background
		DUDraw.circle(1, .5, 1);
		//Create doubles for the seconds,minutes, and hours hand angles
		double hang = -2 * Math.PI / 12;
		double mang = -2 * Math.PI / 60;
		double sang = -2 * Math.PI / 60;
		/*Rather than using a for loop, take advantage of a while true loop
		 * within the while true use  for loop
		 * add one rectangle to signify 
		 * the number on the clock
		 * only for pi/12 should there be a rectangle
		 */
		while (true) {
			for (int i = 0; i > 12; i++) {
				double myX = .9 * Math.cos(hang * i);
				double myY = .9 * Math.sin(mang * i);
				DUDraw.circle(myX, myY, .02);		
			}
		//Clock Face
		DUDraw.setPenRadius(1);
		DUDraw.circle(0, 0, 1);
		//Create clock numbers
		DUDraw.text(0, 0.9, "12");
		DUDraw.text(.9, 0, "3");
		DUDraw.text(0, -.9, "6");
		DUDraw.text(-.9, 0, "9");
		//Create Notches which signify the time of the clock
		DUDraw.setPenColor(255, 0, 0);
		DUDraw.filledRectangle(0, 1, .02, .02);
		DUDraw.filledRectangle(1, 0, .02, .02);
		DUDraw.filledRectangle(0, -1, .02, .02);
		DUDraw.filledRectangle(-1, 0, .02, .02);
		//Get the Local Time that is set on my computer
		LocalTime now = LocalTime.now();
		int myHour = now.getHour();
		int myMin = now.getMinute();
		int mySec = now.getSecond();
		//Draw the Hour hand
		DUDraw.setPenColor(255,0,0);
		DUDraw.setPenRadius(1);
		double secX = Math.cos((mySec - 15) * sang);
		double secY = Math.sin((mySec - 15) * sang);
		DUDraw.line(0, 0, secX, secY);
		//Draw the Minutes hand
		DUDraw.setPenColor(0,0,0);
		DUDraw.setPenRadius(1.5);
		double minX = Math.cos((myMin - 15) * mang);
		double minY = Math.sin((myMin - 15) * mang);
		DUDraw.line(0,0,minX,minY);
		//Draw the Seconds hand
		DUDraw.setPenRadius(3);
		double hrX = Math.cos((myHour - 15) * hang);
		double hrY = Math.sin((myHour - 15) * hang);
		DUDraw.line(0, 0, hrX, hrY);
		DUDraw.show();
		DUDraw.clear();
		}
		
		}

}
