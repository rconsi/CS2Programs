
public class ClockPoints {

}
