package edu.du.considine;
import java.awt.Color;

import edu.du.dudraw.DUDraw;

public class TrigDrawingMethods {
	private static int nGonCounter = 0;
	private static int spiralCounter = 0;
	private static int spirographCounter = 0;
	private static Color PINK = new Color(245,66,220);
	private static Color LBLUE = new Color(66, 245, 221);
	private static Color LGREEN = new Color(66, 245, 69);
	
	public static void  filledRegularNgon(int centerX, int centerY, int radius, int n) {
		double[] xCord =  new double[n];
		double[] yCord =new double[n];
		double deg = 0;
		double inc = 360 / n;
		for(int i = 0; i < n; i++) {
				yCord[i] = centerX + radius * Math.cos(Math.toRadians(deg));
				xCord[i] = centerY + radius * Math.sin(Math.toRadians(deg));
		 		deg += inc;
		} 
		DUDraw.filledPolygon(xCord,yCord);
		nGonCounter++;
	}
	static void spiral(int centerX, int centerY, int maxRadius, int numTurns, int numSegments) {
	int x1 = centerX;
	int y1 = centerY;
	int radius = 0;
	double incrementRad = maxRadius / (Math.PI * 2);
	
	for (int i = 0; i < numSegments; i++) {
		radius += incrementRad;
		int x2 = x1;
		int y2 = y1;
		x1 = (int) (centerX + radius * Math.cos((Math.PI * 2 * i / numSegments ) * numTurns));
		y1 = (int) (centerY + radius * Math.sin((Math.PI * 2 * i / numSegments ) * numTurns));
		DUDraw.line(x1,y1,x2,y2);
		}
	spiralCounter++;
	}
	static void spirograph(int centerX, int centerY, int totalRadius, int numDrawing, int radius) {
		double[] xCord = new double[(int) numDrawing];
		double[] yCord = new double[(int) numDrawing];
		double deg = 0;
		double inc = 360 / numDrawing;
		for(int i = 0; i < numDrawing; i++) {
			xCord[i] = centerY + radius * Math.sin(Math.toRadians(deg));
			yCord[i] = centerX + radius * Math.cos(Math.toRadians(deg));
			deg += inc;
			DUDraw.circle(xCord[i], yCord[i], radius);
		}
		spirographCounter++;
	}
	public static Color getPink() {
		return PINK;
	}
	public static Color getLightBlue() {
		return LBLUE;
	}
	public static Color getLightGreen() {
		return LGREEN;
	}
	public static int getNGonCount() {
		return nGonCounter;
	}
	public static int getSpiralCount() {
		return spiralCounter;
	}
	public static int getSpiroGraphCount() {
		return spirographCounter;
	}
}
