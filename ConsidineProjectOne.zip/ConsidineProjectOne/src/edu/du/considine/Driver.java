package edu.du.considine;
import edu.du.dudraw.DUDraw;

public class Driver  extends TrigDrawingMethods{

	public static void main(String[] args) {
		//CanvasSetup
		DUDraw.setCanvasSize(600, 600);
		DUDraw.setScale(100,-100);
		//FilledRegularNgon testing with color chooser and nGonCounter value
		DUDraw.setPenColor(getPink());
		filledRegularNgon(2,2,40,12);
		DUDraw.setPenColor(getLightBlue());
		filledRegularNgon(2,2,20,6);
		System.out.println("\nN-Gon Count: " +getNGonCount());
		//Spiral test
		DUDraw.setPenColor(getLightBlue());
		spiral(1,2,10,400,500);
		DUDraw.setPenColor(getPink());
		spiral(1,2,2,400,400);
		System.out.println("\nSpiral Count: " +getSpiralCount());
		//Spirograph test
		DUDraw.setPenColor(getLightGreen());
		spirograph(2,2,2,20,10);
		DUDraw.setPenColor(getLightBlue());
		spirograph(2,2,2,20,20);
		DUDraw.setPenColor(getPink());
		spirograph(2,2,5,20,40);
		
		System.out.println("\nSpiroGraph Count: " + getSpiroGraphCount());
		DUDraw.show();
	}

}
